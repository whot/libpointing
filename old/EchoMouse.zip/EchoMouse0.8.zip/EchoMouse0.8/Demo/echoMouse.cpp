/*
		Gery Casiez
		http://www.lifl.fr/~casiez
		
		echoMouse.cpp
		
		September 2010		
*/

#include "echoMouse.h"

EchoMouse::EchoMouse(void)
{
  
}


int EchoMouse::Init() 
{
  // Open the device using the VID, PID,
  // and optionally the Serial number.
  handle = hid_open(0x4d8, 0x3f, NULL);
  if (handle == NULL) {
    std::cerr << "Pb opening EchoMouse" << std::endl;
    return -1;
  }
  return 0;
}

void EchoMouse::Send(unsigned char x, unsigned char y, unsigned char scroll, bool leftClick, bool middleClick, bool rightClick)
{
  // http://www.computer-engineering.org/ps2mouse/
  unsigned char data[4] = {x, y, scroll, 0};
  unsigned char buttons = 0x8;
  if (leftClick) buttons |= 0x1;
  if (rightClick) buttons |= 0x2;
  if (middleClick) buttons |= 0x4;

  data[3] = buttons;
  int res = hid_write(handle, data, sizeof(data));
  //int res= hid_send_feature_report(handle, data, sizeof(data));
}

EchoMouse::~EchoMouse(void)
{

}



