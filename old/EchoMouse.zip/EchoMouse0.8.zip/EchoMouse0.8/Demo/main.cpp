#include <math.h>
#include "echoMouse.h"

EchoMouse echoMouse;


void circle() {
  float radius = 5.0;
  for (float theta=0.0; theta<=360.0*6.0; theta+=1) {
    echoMouse.Send(radius*cos(theta*3.1415/180.0),radius*sin(theta*3.1415/180.0),0,false, false, false);
    //usleep(10000);
  }
}

void leftClick() {
  echoMouse.Send(0,0,0, true, false, false);
  echoMouse.Send(0,0,0, false, false, false);
}


int main(int argc, char* argv[]) {

  if (echoMouse.Init() != 0) {
    std::cerr << "Pb opening EchoMouse" << std::endl;
    return -2;
  }

  circle();

  return 0;
}
