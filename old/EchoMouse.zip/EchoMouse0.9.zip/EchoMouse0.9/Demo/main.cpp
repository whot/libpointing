#include <math.h>
#include "echoMouse.h"
#ifdef WIN32
	#include <windows.h>
#endif

EchoMouse echoMouse;


void circle() {
  float radius = 5.0;
  for (float theta=0.0; theta<=360.0*6.0; theta+=1) {
    if (int ret = echoMouse.Send(radius*cos(theta*3.1415/180.0),radius*sin(theta*3.1415/180.0),0,false, false, false) <= 0)
		std::cerr << "Sending failed!" << ret << std::endl;
	// When using feature reports, a sleep is required to avoid loosing reports
	// Try different values to see how fast you can go without loosing reports
	// Feature reports are required on Windows
	// Output and feature reports work on OSX and Linux (=> prefer using output reports)

    //usleep(10000);
	#ifdef WIN32
		Sleep(8);
	#endif
  }
}

void leftClick() {
  echoMouse.Send(0,0,0, true, false, false);
  echoMouse.Send(0,0,0, false, false, false);
}


int main(int argc, char* argv[]) {

  if (echoMouse.Init() != 0) {
    std::cerr << "Pb opening EchoMouse" << std::endl;
    return -2;
  }

  circle();

  return 0;
}
