/*
		Gery Casiez
		http://www.lifl.fr/~casiez
		
		echoMouse.h
		
		September 2010		
*/

#ifndef _ECHOMOUSE_H_
#define _ECHOMOUSE_H_

#include <iostream>
#include "hidapi.h"

class EchoMouse{
private :
  hid_device *handle;
public :
  EchoMouse(void);
  int Init();
  int Send(unsigned char x, unsigned char y, unsigned char scroll, bool leftClick, bool middleClick, bool rightClick);
  ~EchoMouse(void);
};

#endif
