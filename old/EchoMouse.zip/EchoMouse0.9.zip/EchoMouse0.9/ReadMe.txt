EchoMouse version 0.9 - 04/02/2012
http://libpointing.org/echomouse.html

Author: Géry Casiez http://www.lifl.fr/~casiez

Related paper: Géry Casiez and Nicolas Roussel. 2011. No more bricolage! methods and tools to characterize, replicate and compare pointing transfer functions. In Proceedings of the 24th annual ACM symposium on User interface software and technology (UIST '11). ACM, New York, NY, USA, 603-614. DOI=10.1145/2047196.2047276 http://doi.acm.org/10.1145/2047196.2047276

- Used MicroChip PICkit 2 to program the PIC18LF14K50 but other programmers work too: MPLAB PM3, MPLAB REAL ICE, MPLAB ICD 2, MPLAB ICD 3, PICkit 3 

> Instruction notes for recompiling EchoMouse firmware. ONLY possible on Windows
1) Download required softwares
- MPLAB IDE (tested with version 8.83 - filename: MPLAB_IDE_8_83.zip) on http://www.microchip.com
- MPLAB C18 Academic (tested with version 3.31 - filename: MPLAB-C18-Academic-v3_31.exe)
2) Install MPLAB IDE then MPLAB C18
3) Open echomouse.mcp
4) You can now compile and flash the device

******************-------------------------------------------------------******************

> Burn EchoMouse firmware on the PIC without recompiling (Windows, Linux, Mac OS X)
1) Download and install PICkit 2 programmer software (tested with version 2.61 - filename PICKit2v2.61.00Setup_A.zip)
2) File > Import Hex
3) Locate EchoMouse.hex
4) Hit the Write button. If "Programming Successful" appears, you're done!
Note: also successfully tested using pk2cmd (available from www.microchip.com) on Mac OS X (10.6.8):
pk2cmd -F EchoMouse.hex -M -P

******************-------------------------------------------------------******************

> Compile Demo app
Based on HIDAPI: http://www.signal11.us/oss/hidapi/
API slightly modified to work on Windows.
